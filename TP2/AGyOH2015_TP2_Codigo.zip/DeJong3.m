% Algoritmos Geneticos y Optimizacion Heuristicas - 2015
%

function [z] = DeJong3(x)
z = sum(floor(x));
