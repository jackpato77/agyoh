% Algoritmos Geneticos y Optimizacion Heuristica - U.T.N. - F.R.T.
%   Trabajo Practico Nro 2 - 2015
%
% Realiza el cruzamiento de las soluciones P1 y P2 de la población.
%
% Parametros:
% - P1, P2: individuos a cruzar (vectores fila sin la columna de fitness)
%
% Salida:
% - C1, C2: soluciones resultado del cruzamiento (tienen el mismo tamaño 
%   que P1 y P2.

function [C1, C2] = xover(P1, P2)

% ... COMPLETAR AQUI ....

end %function
